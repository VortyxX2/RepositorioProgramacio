package model;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;


public class Funciones {

    // 1. Crear carpeta
    public static void createFolder(String folderName) {
        File folder = new File(folderName);
        if (!folder.exists()) {
            folder.mkdir();
        }
    }

    // 2. Crear o añadir contenido a un archivo
    public static void createFile(String path, String fileName, String content) {
        File file = new File(path + "/" + fileName);
        try {
            FileWriter fw = new FileWriter(file, true); // true para añadir
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(content);
            bw.newLine();
            bw.close();
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo.");
        }
    }

    // 3. Mostrar listado de archivos en una carpeta
    public static String[] showListFiles(String path) {
        File folder = new File(path);
        return folder.list();
    }

    // 4. Mostrar contenido de un archivo
    public static String showFile(String path, String fileName) {
        File file = new File(path + "/" + fileName);
        StringBuilder content = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("\n");
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo.");
        }
        return content.toString();
    }

    // 5. Sobrescribir un archivo (si no existe, false)
    public static boolean overWriteFile(String path, String fileName, String newContent) {
        File file = new File(path + "/" + fileName);
        if (!file.exists()) {
            return false;
        }
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, false)); // false para sobrescribir
            bw.write(newContent);
            bw.newLine();
            bw.close();
        } catch (IOException e) {
            System.out.println("Error al sobrescribir el archivo.");
        }
        return true;
    }

    // 6. Borrar archivo
    public static void deleteFile(String path, String fileName) {
        File file = new File(path + "/" + fileName);
        if (file.exists()) {
            file.delete();
        }
    }

    // 7. Contar caracteres
    public static int countChars(String path, String fileName) {
        File file = new File(path + "/" + fileName);
        int count = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            int c;
            while ((c = br.read()) != -1) {
                count++;
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al contar caracteres.");
        }
        return count;
    }

    // 8. Contar palabras
    public static int countWords(String path, String fileName) {
        File file = new File(path + "/" + fileName);
        int count = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                String[] words = line.trim().split("\\s+");
                count += words.length;
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al contar palabras.");
        }
        return count;
    }

    // 9. Reemplazar palabras
    public static String swapWords(String path, String fileName, String oldWord, String newWord) {
        File file = new File(path + "/" + fileName);
        StringBuilder newContent = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                newContent.append(line.replaceAll(oldWord, newWord)).append("\n");
            }
            br.close();
            // Sobrescribimos con el contenido nuevo
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, false));
            bw.write(newContent.toString());
            bw.close();
        } catch (IOException e) {
            System.out.println("Error al reemplazar palabras.");
        }
        return newContent.toString();
    }

     // 10. Crear un PDF con el contenido de un archivo de texto

    public static void printPDF(String path, String fileName) throws Exception {
        String textContent = showFile(path, fileName);
        String pdfPath = path + File.separator + fileName.replace(".txt", "") + ".pdf";
        Document document;
        document = new Document();
        try {
            // Corregido: se debe pasar el documento correcto a PdfWriter.getInstance
            PdfWriter.getInstance(document, new FileOutputStream(pdfPath));
            document.open();
            document.add(new Paragraph(textContent));
            document.close();
            System.out.println("PDF creado correctamente en: " + pdfPath);
        } catch (IOException e) {
            throw new Exception("Error creando PDF: " + e.getMessage());
        }
    }
}

