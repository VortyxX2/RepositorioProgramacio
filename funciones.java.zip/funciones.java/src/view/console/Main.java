package view.console;

import java.util.Scanner;
import model.Funciones;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        String path, fileName, content, oldWord, newWord;

        do {
            System.out.println("\n=== MENU DE GESTION DE ARCHIVOS ===");
            System.out.println("1. Crear carpeta");
            System.out.println("2. Crear archivo con texto (o anadir)");
            System.out.println("3. Listar archivos de una carpeta");
            System.out.println("4. Mostrar contenido de un archivo");
            System.out.println("5. Sobrescribir archivo");
            System.out.println("6. Borrar archivo");
            System.out.println("7. Contar caracteres de un archivo");
            System.out.println("8. Contar palabras de un archivo");
            System.out.println("9. Reemplazar palabra en archivo");
            System.out.println("10. Imprimir archivo como PDF (no implementado)");
            System.out.println("0. Salir");
            System.out.print("Elige una opcion: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Por favor, introduce un número valido.");
                opcion = -1;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Introduce el nombre de la carpeta: ");
                    path = sc.nextLine();
                    Funciones.createFolder(path);
                    break;

                case 2:
                    System.out.print("Ruta donde guardar el archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo (ej: notas.txt): ");
                    fileName = sc.nextLine();
                    System.out.print("Contenido a escribir: ");
                    content = sc.nextLine();
                    Funciones.createFile(path, fileName, content);
                    break;

                case 3:
                    System.out.print("Ruta de la carpeta: ");
                    path = sc.nextLine();
                    String[] files = Funciones.showListFiles(path);
                    if (files != null) {
                        System.out.println("Archivos encontrados:");
                        for (String file : files) {
                            System.out.println("- " + file);
                        }
                    } else {
                        System.out.println("No se pudo acceder a la carpeta.");
                    }
                    break;

                case 4:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo: ");
                    fileName = sc.nextLine();
                    String texto = Funciones.showFile(path, fileName);
                    System.out.println("Contenido del archivo:\n" + texto);
                    break;

                case 5:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo: ");
                    fileName = sc.nextLine();
                    System.out.print("Nuevo contenido: ");
                    content = sc.nextLine();
                    boolean ok = Funciones.overWriteFile(path, fileName, content);
                    if (ok) {
                        System.out.println("Archivo sobrescrito correctamente.");
                    } else {
                        System.out.println("El archivo no existe.");
                    }
                    break;

                case 6:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo: ");
                    fileName = sc.nextLine();
                    Funciones.deleteFile(path, fileName);
                    System.out.println("Archivo borrado si existía.");
                    break;

                case 7:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo: ");
                    fileName = sc.nextLine();
                    int chars = Funciones.countChars(path, fileName);
                    System.out.println("Numero de caracteres: " + chars);
                    break;

                case 8:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo: ");
                    fileName = sc.nextLine();
                    int words = Funciones.countWords(path, fileName);
                    System.out.println("Número de palabras: " + words);
                    break;

                case 9:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo: ");
                    fileName = sc.nextLine();
                    System.out.print("Palabra a reemplazar: ");
                    oldWord = sc.nextLine();
                    System.out.print("Nueva palabra: ");
                    newWord = sc.nextLine();
                    String nuevoTexto = Funciones.swapWords(path, fileName, oldWord, newWord);
                    System.out.println("Nuevo contenido:\n" + nuevoTexto);
                    break;

                case 10:
                    System.out.print("Ruta del archivo: ");
                    path = sc.nextLine();
                    System.out.print("Nombre del archivo (ej: notas.txt): ");
                    fileName = sc.nextLine();
                    try {
                        Funciones.printPDF(path, fileName);
                    } catch (Exception e) {
                        System.out.println("Error al generar el PDF: " + e.getMessage());
                    }
                    break;
                    
                case 0:
                    System.out.println("Hasta luego!");
                    break;

                default:
                    System.out.println("Opcion no valida.");
            }

        } while (opcion != 0);

        sc.close();
    }
}
